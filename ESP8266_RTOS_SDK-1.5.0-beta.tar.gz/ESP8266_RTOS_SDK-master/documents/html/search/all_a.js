var searchData=
[
  ['link_5fcnt',['link_cnt',['../structespconn.html#a44c66baf2083925ae34e6ff46e7ec281',1,'espconn']]],
  ['local_5fip',['local_ip',['../struct__esp__tcp.html#a2b79759620ce85a36254e2b07c86b62b',1,'_esp_tcp::local_ip()'],['../struct__esp__udp.html#a2b79759620ce85a36254e2b07c86b62b',1,'_esp_udp::local_ip()']]],
  ['local_5fport',['local_port',['../struct__esp__tcp.html#a009e2d58737d2223ce009dc0631e65dc',1,'_esp_tcp::local_port()'],['../struct__esp__udp.html#a009e2d58737d2223ce009dc0631e65dc',1,'_esp_udp::local_port()']]],
  ['log_5fblock_5fsize',['log_block_size',['../structesp__spiffs__config.html#ac7518f38292532ca42fd8ed8a290259b',1,'esp_spiffs_config']]],
  ['log_5fpage_5fsize',['log_page_size',['../structesp__spiffs__config.html#a0cfa1078dbb0a9591e9955d6dd0ad13a',1,'esp_spiffs_config']]]
];
