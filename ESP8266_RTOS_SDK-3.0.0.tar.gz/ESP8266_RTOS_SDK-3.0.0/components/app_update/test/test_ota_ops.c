#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>

#include <unity.h>
#include <test_utils.h>
#include <esp_ota_ops.h>


/* These OTA tests currently don't assume an OTA partition exists
   on the device, so they're a bit limited
*/

TEST_CASE("esp_ota_begin() verifies arguments", "[ota]")
{
    const esp_partition_t *running = esp_ota_get_running_partition();
    esp_partition_t partition;
    static esp_ota_handle_t handle = 0;

    if (handle != 0) { /* clean up from any previous test */
        esp_ota_end(handle);
        handle = 0;
    }

    /* running partition & configured boot partition are same */
    TEST_ASSERT_NOT_NULL(running);

    /* trying to 'begin' on running partition fails */
    TEST_ASSERT_NOT_EQUAL(ESP_OK, esp_ota_begin(running, OTA_SIZE_UNKNOWN, &handle));
    TEST_ASSERT_EQUAL(0, handle);

    memcpy(&partition, running, sizeof(esp_partition_t));
    partition.address--;

    /* non existent partition fails */
    TEST_ASSERT_EQUAL_HEX(ESP_ERR_NOT_FOUND, esp_ota_begin(&partition, OTA_SIZE_UNKNOWN, &handle));
    TEST_ASSERT_EQUAL(0, handle);
}

TEST_CASE("esp_ota_get_next_update_partition logic", "[ota]")
{
    const esp_partition_t *running = esp_ota_get_running_partition();
    const esp_partition_t *factory = esp_partition_find_first(ESP_PARTITION_TYPE_APP,
                                                              ESP_PARTITION_SUBTYPE_APP_FACTORY, NULL);
    const esp_partition_t *ota_0 = esp_partition_find_first(ESP_PARTITION_TYPE_APP,
                                                            ESP_PARTITION_SUBTYPE_APP_OTA_0, NULL);
    const esp_partition_t *ota_1 = esp_partition_find_first(ESP_PARTITION_TYPE_APP,
                                                            ESP_PARTITION_SUBTYPE_APP_OTA_1, NULL);
    const esp_partition_t *ota_2 = esp_partition_find_first(ESP_PARTITION_TYPE_APP,
                                                            ESP_PARTITION_SUBTYPE_APP_OTA_2, NULL);

    TEST_ASSERT_NOT_NULL(running);
    TEST_ASSERT_NOT_NULL(factory);
    TEST_ASSERT_NOT_NULL(ota_0);
    TEST_ASSERT_NOT_NULL(ota_1);
    TEST_ASSERT_NULL(ota_2); /* this partition shouldn't exist in test partition table */

    TEST_ASSERT_EQUAL_PTR(factory, running); /* this may not be true if/when we get OTA tests that do OTA updates */ 

    /* (The test steps verify subtypes before verifying pointer equality, because the failure messages are more readable
       this way.)
     */

    /* Factory app OTA updates OTA 0 slot */
    const esp_partition_t *p = esp_ota_get_next_update_partition(NULL);
    TEST_ASSERT_EQUAL_HEX8(ESP_PARTITION_SUBTYPE_APP_OTA_0, p->subtype);
    TEST_ASSERT_EQUAL_PTR(ota_0, p);

    p = esp_ota_get_next_update_partition(factory);
    TEST_ASSERT_EQUAL_HEX8(ESP_PARTITION_SUBTYPE_APP_OTA_0, p->subtype);
    TEST_ASSERT_EQUAL_PTR(ota_0, p);


    /* OTA slot 0 updates OTA slot 1 */
    p = esp_ota_get_next_update_partition(ota_0);
    TEST_ASSERT_EQUAL_HEX8(ESP_PARTITION_SUBTYPE_APP_OTA_1, p->subtype);
    TEST_ASSERT_EQUAL_PTR(ota_1, p);
    /* OTA slot 1 updates OTA slot 0 */
    p = esp_ota_get_next_update_partition(ota_1);
    TEST_ASSERT_EQUAL_HEX8(ESP_PARTITION_SUBTYPE_APP_OTA_0, p->subtype);;
    TEST_ASSERT_EQUAL_PTR(ota_0, p);
}

